import os
import pandas as pd
import numpy as np
from pathlib import Path
import re
import subprocess as sp
import sys
from datetime import time, datetime, date
import pyodbc
import warnings
warnings.filterwarnings("ignore")
import openpyxl
from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill, Border, Side, Alignment, Protection, Font
from openpyxl.chart.label import DataLabelList
from colorama import init
from termcolor import colored
import shutil
from bs4 import BeautifulSoup
def prGreen(skk): print("\033[92m {}\033[00m" .format(skk))
def prYellow(skk): print("\033[93m {}\033[00m" .format(skk))
def prRed(skk): print("\033[91m {}\033[00m" .format(skk))
def prCyan(skk): print("\033[96m {}\033[00m" .format(skk))
init()

restore_point = sys.stdout
################################################################################
Image=input(r"trb.SoftwareImage = ")
tag=input(r"trb.Tag LIKE '% %': ")

Tag="%" + tag + "%"

print("Image:"+Image)
print("Tag:"+Tag)

def SQL(Image, Tag):


    query="""SELECT distinct(trg.RequestGroupID), tr.RequestID, trg.RequestedBy, trb.Tag, trtc.TestPlanName, tb.HostName, tso.StatusName, trb.HardwareType,trb.HardwareVersion, trgd.RequeueType, tr.LinkedRequest, trco.ReasonCode, trg.RequestTimeStamp, tp.PoolName,  min(tra.StartDateTime) as StartDateTime, max(tra.EndDateTime) as EndDateTime, DATEDIFF(minute, trg.RequestTimeStamp, min(tra.startdatetime)) as 'QueuedTime in mins', DATEDIFF(minute, min(tra.startdatetime), max(tra.EndDateTime)) as 'ExecutionTime in mins', tbso.BuildSourceName, trb.SoftwareProduct, trb.SoftwareProductBuild, trb.SoftwareImage, links = Stuff((SELECT DISTINCT ', ' + HTMLLink AS [text()] FROM dbo.tblsessiondata p WHERE p.RequestID = tr.RequestID FOR XML PATH ('')),1,2,'')
    FROM lap.tblRequestGroup trg
    inner join lap.tblRequest tr on tr.RequestGroupID = trg.RequestGroupID
    inner join lap.tblPool tp on tp.PoolID = trg.PoolID
    inner join lap.tblStatusOption tso on tso.StatusOptionID = trg.StatusOptionID
    inner join lap.tblRequestBuild trb on trb.RequestGroupID = trg.RequestGroupID
    inner join lap.tblRequestTestCase trtc on trtc.RequestID = tr.RequestID
    left join lap.tblTestBed tb on tb.TestBedID = tr.TestBedID
    inner join lap.tblBuildSourceOption tbso on tbso.BuildSourceID = trb.BuildSourceID
    inner join lap.tblRequestGroupDetail trgd on trgd.RequestGroupDetailID = trg.RequestGroupDetailID
    inner join lap.tblRequestAction tra on tra.RequestID = tr.RequestID
    left join lap.tblReasonCodeOptions  trco on trco.ReasonCodeID = trg.ReasonCode
    where trb.RequestID is not null and tbso.BuildSourceName = 'QCA_DEV_POSTCOMMIT' and trb.SoftwareImage = '%s' and trb.Tag LIKE '%s'
    group by trg.RequestGroupID, tr.RequestID, trg.RequestedBy, tp.PoolID, tp.PoolName, tso.StatusName, trgd.RequeueType, tr.LinkedRequest, trco.ReasonCode, trb.Tag, tb.HostName, trtc.TestPlanName, trg.RequestTimeStamp, tbso.BuildSourceName, trb.SoftwareProduct, trb.SoftwareProductBuild, trb.SoftwareImage, trb.HardwareType, trb.HardwareVersion
    order by trb.Tag, trtc.TestPlanName, trb.HardwareType, trg.RequestGroupID desc;"""%(Image,Tag)

    #############################################################################################################
    #driver = "{Microsoft SQL Server (TCP/IP)}"
    driver = "{SQL Server}"
    server = "QCASQLPRD2"
    database = "QCA_RPT"
    username = "QSPRAppUser"
    password = "$1234Qual"
    conn = pyodbc.connect("DRIVER=" + driver
    + ";SERVER=" + server
    + ";DATABASE=" + database
    + ";UID=" + username
    + ";PWD=" + password )

    cursor = conn.cursor()

    prGreen('Successfully connected to SQL database')

    df= pd.io.sql.read_sql(query, conn)
    return df

def extract_links(Image, Tag):
    
    df=SQL(Image,Tag)

    hw_type=df["HardwareType"]
    links=df['links']

    RDP=list(set(hw_type))


    List_no=[]
    List_link=[]
    List_ul=[]
    for i in range (len(RDP)):
        List_no.append([])
        List_link.append([])
        List_ul.append([])

    for i in range(0,len(RDP)):
        for j in range(0,len(hw_type)):
            if RDP[i]==hw_type[j]:
                List_no[i].append(j)
                link=links[j]
                List_link[i].append(link)

    for i in range(0, len(RDP)):
        pattern=','
        for j in range (0,len(List_link[i])):
            try:
                match=(re.search(pattern, List_link[i][j]))
                try:
                    n=match.end()
                    #sfe_160_tcp_dl=string[n:n+8]
                    List_ul[i].append(List_link[i][j][:n-1])
                    List_ul[i].append(List_link[i][j][n+1:])
                except:
                    AttributeError
                    List_ul[i].append(List_link[i][j])
            
            except:
                TypeError

    return [RDP, List_ul]


def image_extract(df):
    table=df[2]

    row=None
    for i in range (1,70):
        
        try:
            string = table[0][i]
        except KeyError:
            break

        pattern='Custom Build Location'
        match=(re.search(pattern, string))
        try:
            
            n=match.end()
            row=i
            #print("Custom Build Location found at row %s"%row)
        except AttributeError:
            a=1
    #print(row)

    if row is not None:
        tag=table[1][row][52:76]

    #print('Tag:'+tag)

    ################
    row=None
    for i in range (1,70):
        
        try:
            string = table[0][i]
        except KeyError:
            break

        pattern='Reporting Meta Build'
        match=(re.search(pattern, string))
        try:
            
            n=match.end()
            row=i
            #print("Reporting Meta Build found at row %s"%row)
            break
        except AttributeError:
            a=1
    #print(row)

    if row is not None:
        meta=table[1][row]

    #print('Meta:'+meta)
    return [tag,meta]


def read_html():
    RDP, List_ul = extract_links(Image, Tag)

    DF = []

    for i in range(len(RDP)):
        DF.append([])

    for k in range(0, len(RDP)):
        for items in List_ul[k]:
            df = pd.read_html(items)
            try:
                error0 = df[1][9]
                warning = df[1][8]
                error0 = error0.astype(str)
                warning = warning.astype(str)
                error = warning + error0
                name = df[1][1]
            except KeyError:
                # In case of KeyError, we can ignore or log it.
                pass

            List = []
            for i in range(0, len(error)):
                pattern = r'(CALL_TRACE_FOUND|KERNEL_PANIC_FOUND|CRASH_DUMP_FOUND|CORE_DUMP_FOUND|TARGET_ASSERT_FOUND)'
                match = re.search(pattern, error[i])
                try:
                    if match: # Ensure the match is not None
                        n = match.end()
                        row = i + 1
                        # print("Crash found at row %s" % row)
                        List.append(row)
                except AttributeError:
                    # In case of no match, we continue
                    pass

            List_name = []
            List_error = []
            List_TP = []
            List_Image = []
            List_Tag = []

            for i in range(0, len(List)):
                n = name[List[i] - 1]
                List_name.append(n)
                e = error[List[i] - 1]
                List_error.append(e)
                tp = items
                List_TP.append(tp)
                tag, meta = image_extract(df)
                List_Tag.append(tag)
                List_Image.append(meta)
                

            #print(List_name)
            #print(List)


            ##############################################################
            # Path to your HTML file
            #file_path = r"\\faith\QSPRlog\QCA\CST\2024\10\13\TestCaseLogs\NA-10_13_24_16_18_17_000_638644331119471338.html"
            file_path = items

            # Open and read the HTML file
            with open(file_path, 'r', encoding='utf-8') as file:
                html_content = file.read()

            #print(html_content)
            # Parse the HTML content
            soup = BeautifulSoup(html_content, 'lxml')

            #print(soup[0])

            List1=[]
            # Example: Extract all links in the HTML document
            links = soup.find_all('a')
            for link in links:
                lk=link.get('href')
                List1.append(lk)


            List_logs_path=[]
            for i in range (0, len(List1)):
                #print(List1[i])

                for j in range(0,len(List)):

                    pattern='^%s$'%List[j]
                    match=(re.search(pattern, List1[i]))
                    try:
                        
                        n=match.end()
                        row=i
                        #print("%s found at row %s"%(List[j],row))
                        List_logs_path.append(List1[i+1].strip())
                    except AttributeError:
                        a=1

            #for i in range(0, len(List)):
                #print("Call trace found for the test case: " + List0[i] + " with warning" + List2[i] + " with logs link" + List3[i] )

            df = pd.DataFrame(list(zip(List_name, List_error, List_logs_path, List_TP, List_Image, List_Tag)),
                        columns =['Name', 'Error', 'Logs_Path','TP_Link','Image','Tag'])

            #print(df)

            if not df.empty:
                DF[k].append(df)
    

    return [RDP,DF]



def excel_extract():
    
    RDP,DF=read_html()
    MDF=[]

    wb = openpyxl.Workbook()
    wb.save("%s.xlsx"%Tag)

    #print("start")

    List_DF=[]

    for i in range (len(RDP)):
        List_DF.append([])

    
    for i in range (0, len(RDP)):
        print(RDP[i])
        print(type(DF[i]))
        print(len(DF[i]))
        print(DF[i])
        for j in range (0, len(DF[i])):
            print(type(DF[i][j]))
            print(len(DF[i][j]))
            print(DF[i][j])
    

        if not DF[i]==[]:
            merged_df = pd.concat(DF[i], ignore_index=True)
            #print(merged_df)
            List_DF[i].append(merged_df)

    #print(List_DF)

    for i in range(0, len(RDP)):
        for obj in List_DF[i]:
            if isinstance(obj, pd.DataFrame):
                #print("This object is a DataFrame:")
                #print(obj)
                with pd.ExcelWriter('%s.xlsx'%Tag,mode='a',engine='openpyxl',if_sheet_exists='replace') as writer:  
                    obj.to_excel(writer, sheet_name=RDP[i],index=False, startrow=0)
            else:
                #print("This object is NOT a DataFrame:", obj)
                a=1
    
    workbook = load_workbook('%s.xlsx'%Tag)
    #print("Current sheets:", workbook.sheetnames)
    sheet_to_delete = 'Sheet'

    
    if sheet_to_delete in workbook.sheetnames:
        std = workbook[sheet_to_delete]
        workbook.remove(std)
        print(f"Deleted sheet: {sheet_to_delete}")
    else:
        print(f"Sheet {sheet_to_delete} not found.")
        a=1
    

    # Save the workbook
    try:
        workbook.save('%s.xlsx'%Tag)
    except:
        IndexError
        prGreen("No call trace found")
        sys.exit()
    
def excel_CR():
    
    excel_extract()

    excel1=pd.ExcelFile("%s.xlsx"%Tag)

    sheet_names=excel1.sheet_names

    print(sheet_names)

    DF=[]
    AP=[]
    CT=[]
    CMD=[]
    VEB=[]
    CS=[]
    JR=[]
    CR=[]

    for i in range (len(sheet_names)):
        DF.append([])
        AP.append([])
        CT.append([])
        CMD.append([])
        VEB.append([])
        CS.append([])
        JR.append([])
        CR.append([])
        

    #print(DF)

    for i in range (len(sheet_names)):
        DF[i]=pd.read_excel("%s.xlsx"%Tag, sheet_name=sheet_names[i])

    #print(DF)


    for i in range (len(sheet_names)):
        error=DF[i]["Error"]
        for j in range(len(error)):
            for k in range (1,5):
                pattern='AccessPointUnderTest%s'%k
                string=error[j]
                match=(re.search(pattern, string))
                try:
                    n=match.end()
                    AP[i].append(string[n-21:n])
                except AttributeError:
                    a=1
            
            try:
                print(AP[i][j])
            except IndexError:
                AP[i].append("No AP")
            

    print(AP)

    for i in range (len(sheet_names)):
        logs_path=DF[i]["Logs_Path"]
        for j in range(len(logs_path)):
            path=logs_path[j]
            print(path)
            print(AP[i][j])
            f_name="%s_SerialLog.log"%AP[i][j]
            #print(f_name)
            file=os.path.join(path,f_name)
            #print(file)
            try:
                with open (file, 'r') as log_file:
                    string=log_file.read()
                #print(string)
                pattern="Call trace"
                match=(re.search(pattern, string))
                try:
                    n=match.end()
                    #print(string[n-770:n+770])
                    CT[i].append(string[n-300:n+300])
                except AttributeError:
                    CT[i].append("Attribute error")
            except FileNotFoundError:
                    CT[i].append("No logs")

    for i in range (len(sheet_names)):
        logs_path=DF[i]["Logs_Path"]
        for j in range(len(logs_path)):
            path=logs_path[j]
            cmd=r"Commands\QSPR_commands.txt"
            file_cmd=os.path.join(path,cmd)
            veb=r"QSPR_VerboseLog.txt"
            file_veb=os.path.join(path,veb)
            CMD[i].append(file_cmd)
            VEB[i].append(file_veb)


    for i in range (len(sheet_names)):
        logs_path=DF[i]["Logs_Path"]
        for j in range(0,len(logs_path)):
            try:
                files=os.listdir(logs_path[j])
                #print(files)
                pattern="CrashScope_"
                string=str(files)
                matches = re.finditer(pattern, string)
                end=[]
                for match in matches:
                    #print(f"Match: {match.group()}, Start: {match.start()}, End: {match.end()}")
                    e=match.end()
                    #print(e)
                    end.append(e)
                #print(end)
                for k in range (0, len(end)):
                    try:
                        n=end[k]
                        #print(n)
                        file=string[n-11:n+18]
                        #print(file)
                        path=os.path.join(logs_path[j],file)
                        files1=os.listdir(path)
                        string1=str(files1)
                        #print(string1)
                        pattern1=("JiraTicketInfo")
                        match1=(re.search(pattern1, string1))
                        try:
                            m=match1.end()
                            CS[i].append(file)
                        except AttributeError:
                            a = 1
                            
                    except AttributeError:
                        a=1
                        #print("No CrashScope")
                        CS[i].append("No CrashScope")

                try:
                    print(CS[i][j])
                except IndexError:
                    CS[i].append("No Jira")

            except NotADirectoryError:
                CS[i].append("No logs")

    #print(CS)

    for i in range (len(sheet_names)):
        logs_path=DF[i]["Logs_Path"]
        for j in range(0,len(logs_path)):
            folder_name=CS[i][j]
            path=os.path.join(logs_path[j],folder_name)
            #print(path)
            try:
                files=os.listdir(path)
                #print(files)
                string=str(files)
                pattern=("JiraTicketInfo")
                match=(re.search(pattern, string))
                try:
                    n=match.end()
                    #print(n)
                    file_name="JiraTicketInfo.txt"
                    file_path=os.path.join(path,file_name)
                    with open(file_path) as file:
                        content=file.read().strip()
                    #print(content)
                    JR[i].append(content)
                except AttributeError:
                    a=1
                    #print("No CrashScope")
                    JR[i].append("No JiraTicketInfo")
            except:
                FileNotFoundError
                JR[i].append("No JiraTicketInfo")


    wb=load_workbook("%s.xlsx"%Tag)

    for i in range(len(sheet_names)):
        ws=wb[sheet_names[i]]
        wb.active=ws
        c=ws.cell(row=1, column=7)
        c.value='Call_Trace'
        bold_font = Font(bold=True)
        c.font=bold_font
        c=ws.cell(row=1,column=8)
        c.value='Cmds'
        c.font = bold_font
        c=ws.cell(row=1, column=9)
        c.value='VerboseLog'
        c.font=bold_font
        c=ws.cell(row=1, column=10)
        c.value='CrashScope'
        c.font=bold_font
        c=ws.cell(row=1, column=11)
        c.value='JiraTicketInfo'
        c.font=bold_font



        logs_path=DF[i]["Logs_Path"]
        for j in range(0,len(logs_path)):
            ct=CT[i][j]
            cmd=CMD[i][j]
            veb=VEB[i][j]
            cs=CS[i][j]
            jr=JR[i][j]
            c=ws.cell(row=j+2, column=7)
            c.value=ct
            c=ws.cell(row=j+2, column=8)
            c.value=cmd
            c=ws.cell(row=j+2, column=9)
            c.value=veb
            c=ws.cell(row=j+2, column=10)
            c.value=cs
            c=ws.cell(row=j+2, column=11)
            c.value=jr

    wb.save("%s.xlsx"%Tag)

excel_CR()

prGreen("Excel created with name: " + Tag)
print('end')

